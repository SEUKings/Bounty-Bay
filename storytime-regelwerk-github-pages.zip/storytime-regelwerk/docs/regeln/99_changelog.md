
---
title: Changelog
---

<link rel="stylesheet" href="../assets/style.css">

# Changelog

Hier dokumentiert ihr alle Änderungen am Regelwerk mit Datum und kurzer Begründung.

## 2025-09-07
- Initiale Veröffentlichung der GitHub Pages Vorlage.
- Struktur für Regel-Kapitel angelegt.
- Layout & TOC erstellt.

---
[← Zurück zur Übersicht](/)
